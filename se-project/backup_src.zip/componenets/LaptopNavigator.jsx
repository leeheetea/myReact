import React from "react";
import "../css/LaptopNavigator.css";

const LaptopNavigator = () => {
  return (
    <div className="Laptiopnavigator-container">
      <span>뮤지컬</span>
      <span>연극</span>
      <span>콘서트</span>
    </div>
  );
};

export default LaptopNavigator;
