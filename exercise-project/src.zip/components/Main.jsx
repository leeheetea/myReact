import React from "react";
import Product from "./Product";
import itemData from "../itemData";

const Main = () => {
  return (
    <div>
      <div className="slider"></div>
      <div className="container">
        <div className="row">
          {itemData.map((data, index) => {
            return <Product data={itemData[index]} key={itemData[index].id} />;
          })}
        </div>
      </div>
    </div>
  );
};

export default Main;
