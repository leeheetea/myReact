import React from "react";
import Nav from "react-bootstrap/Nav";
import Navbar from "react-bootstrap/Navbar";

const Product = (props) => {
  console.log(props);
  const { title, imgUrl, price } = props.data;

  return (
    <div className="col-md-4">
      <img src={imgUrl} width="80%" alt={title}></img>
      <h4>{title}</h4>
      <p>{price}</p>
    </div>
  );
};

export default Product;
