import "./App.css";
import Navigation from "./components/Navigation";
import Main from "./components/Main";
import { Routes, Route, Link, useNavigate } from "react-router-dom";

function App() {
  return (
    <>
      <Navigation />
      <Routes>
        <Route path="/" element={<Main />}></Route>
        <Route path="/detail" element={<div>상세 페이지</div>}></Route>
        <Route path="/cart" element={<div>카트 페이지</div>}></Route>
        <Route path="/about" element={<div>about 페이지</div>}></Route>
      </Routes>
    </>
  );
}

export default App;
