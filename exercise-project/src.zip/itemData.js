let itemData = [
  {
    id: 0,
    title: "White and Black",
    imgUrl: "img/shoes1.jpg",
    content: "Born in France",
    price: 120001,
  },
  {
    id: 1,
    title: "Red Knit",
    imgUrl: "img/shoes2.jpg",
    content: "Born in Seoul",
    price: 110000,
  },
  {
    id: 2,
    title: "Grey Yordan",
    imgUrl: "img/shoes3.jpg",
    content: "Born in the States",
    price: 130000,
  },
  {
    id: 3,
    title: "Flowey",
    imgUrl: "img/shoes4.jpg",
    content: "only 5 inches",
    price: 150000,
  },
  {
    id: 4,
    title: "Baby shoes",
    imgUrl: "img/shoes5.jpg",
    content: "for less than 6",
    price: 140000,
  },
  {
    id: 5,
    title: "Red Herring",
    imgUrl: "img/shoes6.jpg",
    content: "Born in France",
    price: 120000,
  },
  {
    id: 6,
    title: "Dark Flowey",
    imgUrl: "img/shoes7.jpg",
    content: "only 5 inches",
    price: 170000,
  },
  {
    id: 7,
    title: "awesome shoes",
    imgUrl: "img/shoes8.jpg",
    content: "for less than 6",
    price: 160000,
  },
  {
    id: 8,
    title: "Mars shoes",
    imgUrl: "img/shoes9.jpg",
    content: "Born in France",
    price: 150000,
  },
];

export default itemData;
